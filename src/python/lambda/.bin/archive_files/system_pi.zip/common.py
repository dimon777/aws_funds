"""
Module which handles generic functions across all APIs
- Insert data to RDS
- Puts custom Cloudwatch metric
"""
import logging
import json
import sys
import os
import base64
from urllib.parse import unquote
from io import StringIO
import io
import pandas as pd
import boto3
import mysql.connector


RDS_SECRET = os.environ['RDS_SECRET']

logging.basicConfig(level=os.environ["LOG_LEVEL"])
LOGGER = logging.getLogger(__name__)

CW_RDS_METRIC = {
    'MetricName': None,
    'Dimensions': [
        {
            'Name': 'rows_count',
            'Value': 'rows_count'
        },
        {
            'Name': 'APP_VERSION',
            'Value': '1.x'
        },
    ],
    'Unit': 'None',
    'Value': 0
}


def gen_sql(rds_df, t_name):
    r_cols = rds_df.columns
    # TODO: function which takes DF, table, constructs dynamic fields for
    # insert and does db insert
    cols = ",".join(["\n" + c for c in r_cols])
    vals = ",".join(['%s' for i in range(len(r_cols))])
    dups = ",".join(["\n" + c + "=values(" + c + ")" for c in r_cols])
    sql = """
        INSERT INTO {} ({})
            VALUES ({})
            ON DUPLICATE KEY UPDATE {}""".format(t_name, cols, vals, dups)
    return sql


def ssm_parameter(param):
    ssm = boto3.client('ssm')
    return ssm.get_parameter(Name=param, WithDecryption=True)[
        'Parameter']['Value']


def get_all_parameters():
    ssm_client = boto3.client('ssm')
    try:
        parameters = {}
        paginator = ssm_client.get_paginator('get_parameters_by_path')
        for page in paginator.paginate(
                Path='/',
                WithDecryption=True,
                Recursive=True):
            for parameter in page['Parameters']:
                parameters[parameter['Name']] = parameter['Value']
        return parameters
    except ClientError:
        logging.error('Error occurred while requesting SSM parameters')


def read_s3_csv(bucket, key, seperator=","):
    s3c = boto3.client('s3')
    result = s3c.get_object(Bucket=bucket, Key=key)
    df = pd.read_csv(
        io.BytesIO(
            result['Body'].read()),
        encoding='utf8',
        sep=seperator)
    return df


def read_str_from_s3(record):
    s3r = boto3.resource('s3')
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    in_object = s3r.Object(bucket, key)
    content = in_object.get()['Body'].read().decode('utf-8')
    return content


def read_json_from_s3_df(record):
    """ Read JSON into a pd dataframe from s3 """
    s3r = boto3.resource('s3')
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    in_object = s3r.Object(bucket, key)
    content = in_object.get()['Body'].read().decode('utf-8')
    json_df = pd.read_json(content, lines=True)
    return json_df


def read_json_from_s3(record):
    """ Read json into string from S3 """
    s3r = boto3.resource('s3')
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    in_object = s3r.Object(bucket, key)
    content = in_object.get()['Body'].read().decode(
        'utf-8').replace("\'", "\"")
    return json.loads(content)


def read_multiline_json_from_s3(record):
    """ read multiline json from s3 into string """
    s3r = boto3.resource('s3')
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    in_object = s3r.Object(bucket, key)
    content = in_object.get()['Body'].read().decode('utf-8')
    return content

def read_byte_content_from_s3(record):
    ''' reads content as is from s3 as utf-8 string '''
    s3r = boto3.resource('s3')
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    in_object = s3r.Object(bucket, key)
    content = in_object.get()['Body'].read()
    return content

def read_csv_from_s3(record, seperator=",", dtype=None):
    s3c = boto3.client('s3')
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    print('DIAG: reading', bucket, key)
    result = s3c.get_object(Bucket=bucket, Key=key)
    df = pd.read_csv(
        io.BytesIO(
            result['Body'].read()),
        encoding='utf8',
        sep=seperator, dtype=dtype)
    return df


def read_avro_from_s3(record):
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    result = boto3.client('s3').get_object(Bucket=bucket, Key=key)
    f = io.BytesIO(result['Body'].read())
    reader = fastavro.reader(f)
    records = [r for r in reader]
    df = DataFrame.from_records(records)
    return df

def read_excel_from_s3(record):
    bucket = record['s3']['bucket']['name']
    key = unquote(record['s3']['object']['key'])
    s3c = boto3.client('s3')
    result = s3c.get_object(Bucket=bucket, Key=key)
    df = pd.ExcelFile(io.BytesIO(result['Body'].read()))
    return df


def read_avro(filepath, encoding, mode='rb'):
    if filepath[:3] == "s3:":
        o = urlparse(filepath, allow_fragments=False)
        key = o.path.lstrip('/')
        bucket = o.netloc
        result = boto3.client('s3').get_object(Bucket=bucket, Key=key)
        f = io.BytesIO(result['Body'].read())
    else:
        f = open(filepath, mode, encoding=encoding)
    reader = fastavro.reader(f)
    records = [r for r in reader]
    df = DataFrame.from_records(records)
    return df


# TODO: True here prone to introduce bogus fileds in the DF
def dump_to_bucket(df, bucket, key, tagset, index=True):
    """
    Dumps pandas dataframe to bucket
    """
    LOGGER.info("Dumping dataframe to: %s/%s", bucket, key)
    f_handle = StringIO()  # StringIO(str(data))
    df.to_csv(f_handle, encoding='utf-8', index=index)
    s3res = boto3.resource('s3')
    s3c = boto3.client('s3')
    s3res.Object(bucket, key).put(Body=f_handle.getvalue())
    s3c.put_object_tagging(Bucket=bucket, Key=key, Tagging=tagset)


def dump_to_s3(key, data, bucket, tagset):
    """
    Dumps data object (avro, json, csv, pandas to S3
    """
    LOGGER.info("Dumping %s object to S3: %s", key, bucket)
    if isinstance(data, pd.DataFrame):
        dump_to_bucket(data, bucket, key, tagset, False)


def dump_to_s3_raw(key, data, bucket, tagset, notify_on_drop=False):
    """
    Dumps data object (avro, json, csv, pandas) to S3 as is
    """
    s3res = boto3.resource('s3')
    env = os.getenv('ENV', 'undef')
    api = os.getenv('API', 'undef')
    try:
        s3res.Object(bucket, key).put(Body=data)
        if tagset:
            s3c = boto3.client('s3')
            s3c.put_object_tagging(Bucket=bucket, Key=key, Tagging=tagset)
        if notify_on_drop:
            slack_notification(
            "green", "{}: API {} | key: {} loaded to DROPZONE".format(
                env, api, key))

    except Exception as ex:
        LOGGER.info(
            "Exception during processing into %s ZONE: %s",
            bucket,
            ex,
            exc_info=True)
        slack_notification(
            "red", "{}: API: {}, key: {} ERROR".format(
                env, api, key))
        raise ex



# TODO: True here prone to introduce bogus fileds in the DF
def dump_to_bucket_csv(df, bucket, key, tagset, index=True):
    """
    Dumps pandas dataframe to bucket
    """
    LOGGER.info("Dumping dataframe as CSV to: %s/%s", bucket, key)
    f_handle = StringIO()  # StringIO(str(data))
    df.to_csv(f_handle, encoding='utf-8', index=index)
    s3res = boto3.resource('s3')
    s3c = boto3.client('s3')
    s3res.Object(bucket, key).put(Body=f_handle.getvalue())
    s3c.put_object_tagging(Bucket=bucket, Key=key, Tagging=tagset)


def dump_to_bucket_json(data_df, bucket, key, tagset, multiline_flag=False):
    """
    Dumps DF to bucket as JSON
    """
    LOGGER.info("Dumping dataframe as JSON to: %s/%s", bucket, key)
    f_handle = StringIO()
    data_df.to_json(f_handle, orient="records", lines=multiline_flag)
    s3res = boto3.resource('s3')
    s3c = boto3.client('s3')
    s3res.Object(bucket, key).put(Body=f_handle.getvalue())
    s3c.put_object_tagging(Bucket=bucket, Key=key, Tagging=tagset)


def dump_to_s3_generic(data, bucket, key, tagset, multiline_flag=False):
    """
    Dumps Pandas df as json or csv depending on extention of the key
    """
    if isinstance(data, pd.DataFrame):
        ext = key.split('.')[-1]
        if ext == 'json':
            return dump_to_bucket_json(data, bucket, key, tagset, multiline_flag)
        if ext == 'csv':
            return dump_to_bucket_csv(data, bucket, key, tagset, False)
    elif isinstance(data, dict):
        return  copy_s3_file(None, data, bucket, key)

    raise Exception("Unknown file format for key: {}".format(key))


def is_json(myjson):
    """
    Returns result if object is valid json
    """
    try:
        json_object = json.loads(myjson)
        LOGGER.debug("json: %s", json_object)
    except ValueError as ex:
        return False
    return True


def put_rds_metric(metric_name, namespace, metric_value):
    """
    Puts custom metric to AWS Cloudwatch
    """
    CW_RDS_METRIC["MetricName"] = metric_name
    CW_RDS_METRIC['Value'] = metric_value
    cloudwatch = boto3.client('cloudwatch')
    cw_resp = cloudwatch.put_metric_data(
        MetricData=[CW_RDS_METRIC], Namespace=namespace)
    return cw_resp


def insert_to_rds(database, table, rds_secret, df, sql=None):
    """
    Inserts data to RDS
    data - [][]
    """
    if sql is None:
        sql = gen_sql(df, table)

    #print("SQL:", sql)
    data = df.values.tolist()
    host, port, user, pwd = get_rds_secret(rds_secret)
    try:
        conn = mysql.connector.connect(host=host,
                                       port=port,
                                       user=user,
                                       password=pwd,
                                       database=database)
    except Exception as ex:
        LOGGER.error(
            "Can not connect to RDS, aborting pipeline: %s Error: %s",
            host,
            ex,
            exc_info=True)
        raise ex

    rows_committed = 0
    chunk_size = 1000  # TODO: better to expose via env var
    try:
        cur = conn.cursor()
        i = 0
        rows = len(data)
        while i < rows:
            chunk = data[i:i + chunk_size]
            i += chunk_size
            cur.executemany(sql, chunk)  # data
            conn.commit()
            rows_committed += cur.rowcount
            print("committed chunk of rows:", cur.rowcount)
        LOGGER.info("Committed {} rows to RDS".format(rows_committed))
    except Exception as ex:
        LOGGER.error("when inserting data to RDS", exc_info=True)
        raise ex
    finally:
        cur.close()
        conn.close()

    return rows_committed


def wait_for_s3_exist(bucket, in_key):
    """ Waits for object to exist in location """
    LOGGER.info("Waiting for object to exist: %s/%s", bucket, in_key)
    s3c = boto3.client('s3')
    waiter = s3c.get_waiter('object_exists')
    waiter.wait(Bucket=bucket, Key=in_key)
    LOGGER.info("Found Object!")


def get_rds_secret(rds_secret):
    """
    See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    """
    LOGGER.info("get_secret() for RDS_SECRET: %s", rds_secret)
    secretmgr = boto3.client('secretsmanager')
    if os.environ.get('LOCAL'):
        return 'localhost', 3306, os.environ['MYSQL_USER'], os.environ['MYSQL_ROOT_PASSWORD']
    secret_val = secretmgr.get_secret_value(SecretId=rds_secret)
    secret = secret_val['SecretString'] if 'SecretString' in secret_val else base64.b64decode(
        secret_val['SecretBinary'])
    j = json.loads(secret)
    user = j['username']
    pwd = j['password']
    host = j['host']
    port = j['port']
    return host, port, user, pwd

def delete_s3_file(API, bucket, key):
    try:
        s3 = boto3.resource('s3')
        s3.Object(bucket, key).delete()
    except Exception as ex:
        message = "lambda: {}: Error during S3 operation on  s3://{}/{} check AWS logs".format(API, bucket, key)
        slack_notification("red", message)
        raise ex

def copy_s3_file(API, copy_source, dest_bucket, dest_key):
    try:
        s3 = boto3.resource('s3')
        s3.meta.client.copy(copy_source, dest_bucket, dest_key)
        print(copy_source, dest_bucket, dest_key)
    except Exception as ex:
        message = "lambda: {}: Error during S3 operation on  s3://{}/{} check AWS logs".format(API, bucket, key)
        slack_notification("red", message)
        raise ex

def copy_big_s3_file(API, copy_source, dest_bucket, dest_key, upload_size):
    """ Copies large files on S3 """
    try:
        s3 = boto3.client('s3')
        source_bucket = copy_source["Bucket"]
        source_key = copy_source["Key"]
        print("Waiting for the file persist in the source bucket")
        waiter = s3.get_waiter("object_exists")
        waiter.wait(Bucket=source_bucket, Key=source_key)
        # new logic to handle files larger then 5GB goes here
        part_info = { 'Parts': [] }
        mparts = int(size/upload_size)
        rem_size = size % upload_size
        print("multipart upload started")
        mp = s3.create_multipart_upload(Bucket=dest_bucket, Key=dest_key)
        uid = mp['UploadId']
        x = 0
        for i in range(mparts):
            rng = "bytes="+str(MPART_SIZE*i)+"-"+str(MPART_SIZE*(i+1)-1)
            part = s3.upload_part_copy(Bucket=dest_bucket, Key=dest_key, CopySource=source_bucket+"/"+source_key,
                PartNumber=i+1, UploadId=uid, CopySourceRange=rng)
            part_info['Parts'].append({ 'PartNumber': i+1, 'ETag': part['CopyPartResult']['ETag'] })
            x += 1
        if rem_size > 0:
            rng = "bytes="+str(MPART_SIZE*x)+"-"+str(MPART_SIZE*x+rem_size-1)
            part = s3.upload_part_copy(Bucket=dest_bucket, Key=dest_key, CopySource=source_bucket+"/"+source_key,
                PartNumber=x+1, UploadId=uid, CopySourceRange=rng)
            part_info['Parts'].append({ 'PartNumber': x+1, 'ETag': part['CopyPartResult']['ETag'] })

        print(part_info)
        s3.complete_multipart_upload(Bucket=dest_bucket, Key=dest_key, UploadId=uid, MultipartUpload=part_info)
        print("multipart upload completed")

    except Exception as ex:
        message = "lambda: {}: Error during file copy s3://{}/{} check AWS logs".format(API, bucket, key)
        slack_notification("red", message)
        raise ex


def tag_s3_object(API, bucket, key, TAGSET):
    """ Tags S3 object with Tagset"""
    try:
        s3 = boto3.client('s3')
        s3.put_object_tagging(
            Bucket=bucket,
            Key=key,
            Tagging=TAGSET
        )
    except Exception as ex:
        message = "lambda: {}: Error during file tagging s3://{}/{} check AWS logs".format(API, bucket, key)
        slack_notification("red", message)
        raise ex

def get_all_s3_keys(bucket, pref, suff=None):
    """Get a list of all keys in an S3 bucket."""
    s3 = boto3.client('s3')
    keys = []
    kwargs = {'Bucket': bucket, 'Prefix': pref}
    #print(kwargs)
    while True:
        resp = s3.list_objects_v2(**kwargs)
        if resp['KeyCount'] == 0:
            break
        for obj in resp['Contents']:
            o = obj['Key']
            if suff is None or (suff is not None and o.endswith(suff)):
                keys.append(o)
        try:
            kwargs['ContinuationToken'] = resp['NextContinuationToken']
        except KeyError:
            break

    return keys


def to_sqs(api, queue_name, message):
    try:
        sqs = boto3.resource('sqs')
        queue = sqs.get_queue_by_name(QueueName=queue_name)
        queue.send_message(MessageBody=message)
    except Exception as ex:
        LOGGER.error(f'{api}: error, sending message to SQS: {queue}: {ex}')
        slack_notification("red", f'{api}: error, sending message to SQS: {queue}')




def main(argv):
    """ Main method """
    LOGGER.info("No main() calls")


if __name__ == "__main__":
    main(sys.argv[1:])
